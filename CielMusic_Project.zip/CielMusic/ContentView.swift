import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var music: MusicPlayer
    @State private var showingImporter = false
    @State private var streamURL = ""
    @State private var showingURLField = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.10, green: 0.07, blue: 0.17), .black, .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()

            VStack(spacing: 22) {
                header

                if let track = music.currentTrack {
                    nowPlaying(track)
                } else {
                    emptyState
                }

                HStack(spacing: 12) {
                    actionButton("Nhập nhạc", icon: "folder.fill") {
                        showingImporter = true
                    }
                    actionButton("Thêm URL", icon: "link") {
                        showingURLField = true
                    }
                }

                if !music.tracks.isEmpty {
                    playlist
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 22)
            .padding(.top, 18)
        }
        .fileImporter(
            isPresented: $showingImporter,
            allowedContentTypes: [.audio, .mp3, .mpeg4Audio, .wav],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls): music.addLocalFiles(urls)
            case .failure(let error): music.errorMessage = error.localizedDescription
            }
        }
        .alert("Thêm nhạc trực tuyến", isPresented: $showingURLField) {
            TextField("https://example.com/song.mp3", text: $streamURL)
                .textInputAutocapitalization(.never)
                .keyboardType(.URL)
            Button("Hủy", role: .cancel) { }
            Button("Phát") {
                music.addStream(from: streamURL)
                streamURL = ""
            }
        } message: {
            Text("Dán URL trực tiếp tới tệp âm thanh hoặc luồng phát mà bạn có quyền sử dụng.")
        }
        .alert("Thông báo", isPresented: Binding(
            get: { music.errorMessage != nil },
            set: { if !$0 { music.errorMessage = nil } }
        )) {
            Button("Đóng", role: .cancel) { music.errorMessage = nil }
        } message: {
            Text(music.errorMessage ?? "")
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("CIEL").font(.system(size: 13, weight: .bold, design: .rounded))
                    .tracking(5).foregroundStyle(.purple.opacity(0.9))
                Text("Music").font(.system(size: 34, weight: .bold, design: .rounded))
            }
            Spacer()
            Image(systemName: "waveform")
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.purple)
                .frame(width: 52, height: 52)
                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 17))
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "music.note.list")
                .font(.system(size: 54))
                .foregroundStyle(.purple)
            Text("Không gian âm nhạc của bạn")
                .font(.title3.bold())
            Text("Nhập bài hát từ Tệp hoặc thêm một đường dẫn âm thanh trực tuyến.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 42)
        .padding(.horizontal, 20)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 26))
    }

    private func nowPlaying(_ track: Track) -> some View {
        VStack(spacing: 18) {
            ZStack {
                RoundedRectangle(cornerRadius: 28)
                    .fill(LinearGradient(colors: [.purple.opacity(0.8), .indigo, .black],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "waveform")
                    .font(.system(size: 70, weight: .light))
                    .foregroundStyle(.white.opacity(0.9))
            }
            .frame(height: 220)

            VStack(spacing: 5) {
                Text(track.title)
                    .font(.title2.bold())
                    .lineLimit(1)
                Text(track.isRemote ? "ĐANG PHÁT • ONLINE" : "ĐANG PHÁT • OFFLINE")
                    .font(.caption.weight(.semibold))
                    .tracking(2)
                    .foregroundStyle(.purple.opacity(0.9))
            }

            VStack(spacing: 7) {
                Slider(value: Binding(
                    get: { music.currentTime },
                    set: { music.seek(to: $0) }
                ), in: 0...max(music.duration, 1))
                HStack {
                    Text(time(music.currentTime))
                    Spacer()
                    Text(time(music.duration))
                }
                .font(.caption.monospacedDigit())
                .foregroundStyle(.white.opacity(0.5))
            }

            HStack(spacing: 42) {
                Button { music.previous() } label: {
                    Image(systemName: "backward.end.fill").font(.title2)
                }
                Button { music.togglePlayback() } label: {
                    Image(systemName: music.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 25, weight: .bold))
                        .foregroundStyle(.black)
                        .frame(width: 66, height: 66)
                        .background(.white, in: Circle())
                }
                Button { music.next() } label: {
                    Image(systemName: "forward.end.fill").font(.title2)
                }
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .padding(.top, 2)
        }
        .padding(18)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 28))
    }

    private var playlist: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Danh sách phát").font(.headline)
                Spacer()
                Text("\(music.tracks.count) bài")
                    .font(.caption).foregroundStyle(.white.opacity(0.5))
            }

            ScrollView {
                VStack(spacing: 8) {
                    ForEach(Array(music.tracks.enumerated()), id: \.element.id) { index, track in
                        HStack(spacing: 12) {
                            Image(systemName: track.isRemote ? "antenna.radiowaves.left.and.right" : "music.note")
                                .foregroundStyle(.purple)
                                .frame(width: 38, height: 38)
                                .background(.purple.opacity(0.13), in: RoundedRectangle(cornerRadius: 12))
                            Button {
                                music.play(at: index)
                            } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(track.title).lineLimit(1)
                                        .foregroundStyle(.white)
                                    Text(track.isRemote ? "Trực tuyến" : "Trong iPhone")
                                        .font(.caption).foregroundStyle(.white.opacity(0.45))
                                }
                            }
                            .buttonStyle(.plain)
                            Spacer()
                            if music.currentTrack?.id == track.id {
                                Image(systemName: "waveform").foregroundStyle(.purple)
                            }
                            Button(role: .destructive) {
                                music.remove(track)
                            } label: {
                                Image(systemName: "trash")
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.4))
                            }
                        }
                        .padding(10)
                        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
                    }
                }
            }
            .frame(maxHeight: 190)
        }
    }

    private func actionButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.08)))
        }
        .buttonStyle(.plain)
    }

    private func time(_ seconds: Double) -> String {
        guard seconds.isFinite else { return "0:00" }
        let value = max(0, Int(seconds))
        return "\(value / 60):" + String(format: "%02d", value % 60)
    }
}
