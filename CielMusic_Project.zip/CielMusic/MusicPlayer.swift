import Foundation
import Combine
import AVFoundation
import MediaPlayer

@MainActor
final class MusicPlayer: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published private(set) var currentIndex: Int? = nil
    @Published private(set) var isPlaying = false
    @Published private(set) var currentTime: Double = 0
    @Published private(set) var duration: Double = 0
    @Published var errorMessage: String?

    private var player: AVPlayer?
    private var timeObserver: Any?
    private var endObserver: NSObjectProtocol?

    var currentTrack: Track? {
        guard let index = currentIndex, tracks.indices.contains(index) else { return nil }
        return tracks[index]
    }

    init() {
        configureAudioSession()
        configureRemoteCommands()
    }

    deinit {
        if let timeObserver, let player {
            player.removeTimeObserver(timeObserver)
        }
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
        }
    }

    private func configureAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
        } catch {
            errorMessage = "Không thể bật chế độ phát nền: \(error.localizedDescription)"
        }
    }

    func addLocalFiles(_ urls: [URL]) {
        let manager = FileManager.default
        let folder = manager.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Music", isDirectory: true)

        do {
            try manager.createDirectory(at: folder, withIntermediateDirectories: true)
            for source in urls {
                let access = source.startAccessingSecurityScopedResource()
                defer { if access { source.stopAccessingSecurityScopedResource() } }

                let destination = folder.appendingPathComponent(source.lastPathComponent)
                if manager.fileExists(atPath: destination.path) {
                    try manager.removeItem(at: destination)
                }
                try manager.copyItem(at: source, to: destination)
                let track = Track(
                    title: destination.deletingPathExtension().lastPathComponent,
                    url: destination,
                    isRemote: false
                )
                tracks.append(track)
            }
            if currentIndex == nil, !tracks.isEmpty {
                play(at: 0)
            }
        } catch {
            errorMessage = "Không nhập được tệp: \(error.localizedDescription)"
        }
    }

    func addStream(from text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let scheme = url.scheme?.lowercased(),
              ["https", "http"].contains(scheme),
              url.host != nil else {
            errorMessage = "Hãy nhập một đường dẫn âm thanh HTTP hoặc HTTPS hợp lệ."
            return
        }

        let name = url.deletingPathExtension().lastPathComponent
        let track = Track(
            title: name.isEmpty ? (url.host ?? "Nhạc trực tuyến") : name,
            url: url,
            isRemote: true
        )
        tracks.append(track)
        play(at: tracks.count - 1)
    }

    func play(at index: Int) {
        guard tracks.indices.contains(index) else { return }
        removeObservers()
        currentIndex = index
        currentTime = 0
        duration = 0

        let item = AVPlayerItem(url: tracks[index].url)
        let newPlayer = AVPlayer(playerItem: item)
        player = newPlayer
        installTimeObserver(on: newPlayer)

        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.next() }
        }

        newPlayer.play()
        isPlaying = true
        updateNowPlaying()
    }

    func togglePlayback() {
        guard let player else {
            if !tracks.isEmpty { play(at: currentIndex ?? 0) }
            return
        }
        if isPlaying {
            player.pause()
            isPlaying = false
        } else {
            player.play()
            isPlaying = true
        }
        updateNowPlaying()
    }

    func next() {
        guard !tracks.isEmpty else { return }
        let nextIndex = ((currentIndex ?? -1) + 1) % tracks.count
        play(at: nextIndex)
    }

    func previous() {
        guard !tracks.isEmpty else { return }
        if currentTime > 3 {
            seek(to: 0)
        } else {
            let previousIndex = ((currentIndex ?? 0) - 1 + tracks.count) % tracks.count
            play(at: previousIndex)
        }
    }

    func seek(to seconds: Double) {
        let time = CMTime(seconds: seconds, preferredTimescale: 600)
        player?.seek(to: time)
    }

    func remove(_ track: Track) {
        guard let index = tracks.firstIndex(of: track) else { return }
        let wasCurrent = currentIndex == index
        tracks.remove(at: index)

        if tracks.isEmpty {
            player?.pause()
            player = nil
            currentIndex = nil
            isPlaying = false
            currentTime = 0
            duration = 0
        } else if wasCurrent {
            play(at: min(index, tracks.count - 1))
        } else if let currentIndex, index < currentIndex {
            self.currentIndex = currentIndex - 1
        }
    }

    private func installTimeObserver(on player: AVPlayer) {
        let interval = CMTime(seconds: 0.5, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            Task { @MainActor in
                guard let self else { return }
                self.currentTime = time.seconds.isFinite ? time.seconds : 0
                let seconds = player.currentItem?.duration.seconds ?? 0
                self.duration = seconds.isFinite ? seconds : 0
                self.updateNowPlaying()
            }
        }
    }

    private func removeObservers() {
        if let timeObserver, let player {
            player.removeTimeObserver(timeObserver)
        }
        timeObserver = nil
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
        }
        endObserver = nil
    }

    private func configureRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.player?.play(); self?.isPlaying = true }
            return .success
        }
        center.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.player?.pause(); self?.isPlaying = false }
            return .success
        }
        center.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.next() }
            return .success
        }
        center.previousTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.previous() }
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let track = currentTrack else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.isRemote ? "Ciel Music • Online" : "Ciel Music • Offline",
            MPNowPlayingInfoPropertyElapsedPlaybackTime: currentTime,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
    }
}
